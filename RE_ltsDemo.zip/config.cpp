#include "config.h"


config::config(void)
{
}


config::~config(void)
{
}
